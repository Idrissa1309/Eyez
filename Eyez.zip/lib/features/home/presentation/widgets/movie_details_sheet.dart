import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../shared/widgets/neon_button.dart';

class MovieDetailsSheet extends StatelessWidget {
  const MovieDetailsSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with close button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(width: 40), // Balance the X button
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white12,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, color: Colors.white70),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          
          const SizedBox(height: 10),
          
          // Poster and Title
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1025&auto=format&fit=crop',
                  width: 90,
                  height: 130,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Interstellar',
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 20),
                        const SizedBox(width: 5),
                        const Text(
                          '4,9',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          '(12.5k)',
                          style: TextStyle(color: Colors.white38, fontSize: 14),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 30),
          
          // Metadata List
          _buildDetailRow(Icons.access_time, 'Durée', '2h 49min'),
          _buildDetailRow(Icons.movie_filter_outlined, 'Genre', 'Science-fiction, Drame'),
          _buildDetailRow(Icons.calendar_today, 'Année', '2014'),
          _buildDetailRow(Icons.person_outline, 'Réalisation', 'Christopher Nolan'),
          _buildPlatformRow('Netflix'),
          _buildDetailRow(Icons.language, 'Langue', 'Français, Anglais'),
          _buildDetailRow(Icons.high_quality, 'Qualité', '4K Ultra HD'),
          
          const SizedBox(height: 25),
          const Text(
            'Synopsis',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          const SizedBox(height: 12),
          const Text(
            'Lorsque la Terre devient inhabitable, un groupe d’explorateurs voyage à travers un trou de ver à la recherche d’une nouvelle planète habitable.',
            style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.5),
          ),
          
          const SizedBox(height: 40),
          
          // Buttons
          Row(
            children: [
              Expanded(
                flex: 2,
                child: NeonButton(
                  text: 'Regarder',
                  onPressed: () {},
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Container(
                  height: 55,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: TextButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.favorite_border, color: Colors.white70),
                    label: const Text(
                      'Ma liste',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.white38),
          const SizedBox(width: 15),
          Text(
            '$label',
            style: const TextStyle(color: Colors.white38, fontSize: 14),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildPlatformRow(String platform) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        children: [
          const Icon(Icons.play_circle_outline, size: 20, color: Colors.redAccent), // Using red for Netflix vibe
          const SizedBox(width: 15),
          const Text(
            'Plateforme',
            style: TextStyle(color: Colors.white38, fontSize: 14),
          ),
          const Spacer(),
          Text(
            platform,
            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
