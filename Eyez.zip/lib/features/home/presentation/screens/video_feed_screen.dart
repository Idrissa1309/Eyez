import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/providers/ambient_provider.dart';
import '../widgets/interaction_overlay.dart';
import '../widgets/movie_details_sheet.dart';

class VideoItem {
  final String title;
  final String description;
  final String videoUrl;
  final Color accentColor;

  VideoItem({
    required this.title,
    required this.description,
    required this.videoUrl,
    required this.accentColor,
  });
}

class VideoFeedScreen extends ConsumerStatefulWidget {
  const VideoFeedScreen({super.key});

  @override
  ConsumerState<VideoFeedScreen> createState() => _VideoFeedScreenState();
}

class _VideoFeedScreenState extends ConsumerState<VideoFeedScreen> {
  final PageController _pageController = PageController();

  final List<VideoItem> _videos = [
    VideoItem(
      title: 'Interstellar',
      description: 'Un voyage au-delà du temps.',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      accentColor: const Color(0xFF00D2FF), // Neon Cyan
    ),
    VideoItem(
      title: 'Dune Part Two',
      description: 'Le destin de l\'univers.',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      accentColor: const Color(0xFFFF9F00), // Amber/Orange
    ),
    VideoItem(
      title: 'Spider-Man',
      description: 'À travers le Spider-Verse.',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      accentColor: const Color(0xFFFF2E93), // Neon Fuchsia
    ),
    VideoItem(
      title: 'The Batman',
      description: 'La vengeance a un visage.',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      accentColor: const Color(0xFFFF0000), // Deep Red
    ),
  ];

  @override
  void initState() {
    super.initState();
    // Set initial color
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(ambientColorProvider.notifier).state = _videos[0].accentColor;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        controller: _pageController,
        onPageChanged: (index) {
          ref.read(ambientColorProvider.notifier).state = _videos[index].accentColor;
        },
        itemCount: _videos.length,
        itemBuilder: (context, index) {
          return VideoPlayerItem(video: _videos[index]);
        },
      ),
    );
  }
}

class VideoPlayerItem extends StatefulWidget {
  final VideoItem video;
  const VideoPlayerItem({super.key, required this.video});

  @override
  State<VideoPlayerItem> createState() => _VideoPlayerItemState();
}

class _VideoPlayerItemState extends State<VideoPlayerItem> {
  late VideoPlayerController _controller;
  bool _initialized = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.video.videoUrl))
      ..initialize().then((_) {
        if (mounted) {
          setState(() {
            _initialized = true;
            _controller.play();
            _controller.setLooping(true);
          });
        }
      }).catchError((error) {
        if (mounted) {
          setState(() {
            _error = error.toString();
          });
        }
        debugPrint('Video Player Error: $error');
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: () {
        showDialog(
          context: context,
          barrierColor: Colors.black54,
          builder: (context) => const InteractionOverlay(),
        );
      },
      onTap: () {
        if (_controller.value.isPlaying) {
          _controller.pause();
        } else {
          _controller.play();
        }
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_initialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size.width,
                height: _controller.value.size.height,
                child: VideoPlayer(_controller),
              ),
            )
          else if (_error != null)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red, size: 40),
                    const SizedBox(height: 10),
                    Text(
                      'Erreur de lecture : $_error',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                    TextButton(
                      onPressed: () {
                        setState(() {
                          _error = null;
                          _initialized = false;
                        });
                        _controller.initialize().then((_) {
                          if (mounted) {
                            setState(() {
                              _initialized = true;
                              _controller.play();
                            });
                          }
                        });
                      },
                      child: const Text('Réessayer', style: TextStyle(color: AppColors.neonCyan)),
                    ),
                  ],
                ),
              ),
            )
          else
            const Center(child: CircularProgressIndicator(color: AppColors.neonCyan)),
            
          // Bottom Info
          Positioned(
            bottom: 140,
            left: 20,
            right: 80,
            child: GestureDetector(
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (context) => const MovieDetailsSheet(),
                );
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.video.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.video.description,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Top Search Icon
          Positioned(
            top: 60,
            right: 20,
            child: IconButton(
              icon: const Icon(Icons.search, color: Colors.white, size: 28),
              onPressed: () {},
            ),
          ),
        ],
      ),
    );
  }
}
