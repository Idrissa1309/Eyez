import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/services/supabase_service.dart';
import '../../../auth/presentation/screens/login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 60),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(),
                const Text(
                  'PROFIL',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.more_vert, color: Colors.white, size: 28),
                  onPressed: () {},
                ),
              ],
            ),
            const SizedBox(height: 30),
            
            // Profile Image
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.neonFuchsia, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.neonFuchsia.withOpacity(0.3),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: const CircleAvatar(
                radius: 50,
                backgroundImage: NetworkImage('https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=1000&auto=format&fit=crop'),
              ),
            ),
            const SizedBox(height: 20),
            
            Text(
              SupabaseService.currentUser?.userMetadata?['username'] ?? 'Alexis',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Text(
              '@${SupabaseService.currentUser?.userMetadata?['username'] ?? 'alexis_cine'}',
              style: const TextStyle(color: AppColors.neonCyan, fontSize: 14),
            ),
            const SizedBox(height: 10),
            const Text(
              'Passionné de films et séries\nÀ la recherche de la prochaine pépite 🎬',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
            const SizedBox(height: 30),
            
            // Stats
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStat('128', 'Abonnements'),
                _buildStat('842', 'Abonnés'),
                _buildStat('2,3K', 'J\'aime'),
                _buildStat('56', 'Listes'),
              ],
            ),
            const SizedBox(height: 30),
            
            // Tabs
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildTab(Icons.movie_outlined, 'Vidéos', isSelected: true),
                _buildTab(Icons.list_alt_outlined, 'Listes'),
                _buildTab(Icons.favorite_border, 'Favoris'),
                _buildTab(Icons.history, 'Historique'),
              ],
            ),
            const SizedBox(height: 20),
            
            // Grid
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.8,
              ),
              itemCount: 9,
              itemBuilder: (context, index) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.surface,
                    image: const DecorationImage(
                      image: NetworkImage('https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1159&auto=format&fit=crop'),
                      fit: BoxFit.cover,
                    ),
                  ),
                );
              },
            ),
            
            const SizedBox(height: 40),
            // Settings Button
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                children: [
                  Icon(Icons.settings_outlined, color: AppColors.textSecondary),
                  SizedBox(width: 15),
                  Text('Paramètres', style: TextStyle(color: Colors.white)),
                  Spacer(),
                  Icon(Icons.arrow_forward_ios, color: AppColors.textSecondary, size: 16),
                ],
              ),
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () async {
                await SupabaseService.signOut();
                if (context.mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                    (route) => false,
                  );
                }
              },
              child: const Text('Se déconnecter', style: TextStyle(color: Colors.redAccent)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      ],
    );
  }

  Widget _buildTab(IconData icon, String label, {bool isSelected = false}) {
    return Column(
      children: [
        Icon(icon, color: isSelected ? AppColors.neonFuchsia : AppColors.textSecondary, size: 24),
        const SizedBox(height: 4),
        if (isSelected)
          Container(height: 2, width: 20, color: AppColors.neonFuchsia),
      ],
    );
  }
}
