import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class SupabaseService {
  static String get _url => dotenv.get('SUPABASE_URL');
  //static String get _anonKey => dotenv.get('SUPABASE_ANON_KEY');
  static String get _publishableKey => dotenv.get('SUPABASE_PUBLISHABLE_KEY');

  static Future<void> init() async {
    await Supabase.initialize(
      url: _url,
      //anonKey: _anonKey,
      publishableKey: _publishableKey,
    );
  }

  static SupabaseClient get client => Supabase.instance.client;

  static User? get currentUser => client.auth.currentUser;

  static Future<AuthResponse> signIn(String email, String password) async {
    return await client.auth.signInWithPassword(email: email, password: password);
  }

  static Future<AuthResponse> signUp(String email, String password, String username) async {
    final response = await client.auth.signUp(
      email: email, 
      password: password,
      data: {'username': username},
    );
    return response;
  }

  static Future<void> signOut() async {
    await client.auth.signOut();
  }
}
